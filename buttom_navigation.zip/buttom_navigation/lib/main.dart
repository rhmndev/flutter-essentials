import 'package:fancy_bottom_navigation/fancy_bottom_navigation.dart';
import 'package:flutter/material.dart';

void main() => runApp(HomePage());

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Fashion',
      home: BottomNavFancy(),
    );
  }
}
class BottomNavFancy extends StatefulWidget {
  @override
  _BottomNavFancyState createState() => _BottomNavFancyState();
}

class _BottomNavFancyState extends State<BottomNavFancy> {
  int currentPage = 0;
  @override
  Widget build(BuildContext context) {
    String title = 'Fashion';
    return Scaffold(

      appBar: AppBar(
        backgroundColor: Colors.pink[200],
        title: Text(
          title,
          style: TextStyle(color: Colors.white),
          textAlign: TextAlign.center,
        ),
      ),
      bottomNavigationBar: FancyBottomNavigation(
        circleColor: Colors.pink[100],
        inactiveIconColor: Colors.red[200],
        tabs: [
          TabData(iconData: Icons.home, title: 'Home'),
          TabData(iconData: Icons.store, title: 'Store'),
          TabData(iconData: Icons.shopping_basket, title: 'Brand')
        ],
        onTabChangedListener: (position){
          setState(() {
            currentPage = position;
          });
        },

      ),
      body: child: Container(
        child: Center(
          child: Text(currentPage.toString(), textScaleFactor:10.0 ,),
        ),
      ),

    );
  }
}
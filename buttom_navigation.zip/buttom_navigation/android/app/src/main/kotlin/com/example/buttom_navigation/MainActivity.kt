package com.example.buttom_navigation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

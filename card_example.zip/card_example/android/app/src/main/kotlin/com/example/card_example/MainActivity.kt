package com.example.card_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

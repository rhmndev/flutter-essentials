package com.example.getting_info_from_custom_widget

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

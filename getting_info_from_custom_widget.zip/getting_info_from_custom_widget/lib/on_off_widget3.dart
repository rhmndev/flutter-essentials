import 'package:flutter/material.dart';

class OnOffWidget3 extends StatefulWidget {
  final bool initialState;
  final Function(bool)? onStateChange;

  OnOffWidget3({this.initialState = false, this.onStateChange});

  // const OnOffWidget3({super.key});

  @override
  State<OnOffWidget3> createState() => _OnOffWidget3State();
}

class _OnOffWidget3State extends State<OnOffWidget3> {
  late bool isOn;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    isOn = widget.initialState;
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        setState(() {
          isOn = !isOn;
        });

        if (widget.onStateChange != null) {
          widget.onStateChange!(isOn);
        }
      },
      child: Container(
          width: 100,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.black,
            borderRadius: BorderRadius.circular(25),
          ),
          child: AnimatedContainer(
            margin: EdgeInsets.only(
              top: 5,
              bottom: 5,
              left: isOn ? 55 : 5,
              right: isOn ? 5 : 55,
            ),
            width: 40,
            height: 40,
            duration: Duration(milliseconds: 200),
            decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isOn ? Colors.yellow : Colors.grey),
          )),
    );
  }
}

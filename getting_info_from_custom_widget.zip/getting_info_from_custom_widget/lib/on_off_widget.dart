import 'package:flutter/material.dart';

class OnOffWidget1 extends StatelessWidget {
  // const OnOffWidget1({super.key});
  final bool isOn;

  OnOffWidget1(this.isOn);

  @override
  Widget build(BuildContext context) {
    return Container(
        width: 100,
        height: 50,
        decoration: BoxDecoration(
          color: Colors.black,
          borderRadius: BorderRadius.circular(25),
        ),
        child: Container(
          margin: EdgeInsets.only(
            top: 5,
            bottom: 5,
            left: isOn ? 55 : 5,
            right: isOn ? 5 : 55,
          ),
          width: 40,
          height: 40,
          decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isOn ? Colors.yellow : Colors.grey),
        ));
  }
}

class Person {
  String? name;
  function(String name) {
    String doingHobby;
  }
}

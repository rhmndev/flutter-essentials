import 'package:flutter/material.dart';
import 'package:getting_info_from_custom_widget/on_off_widget3.dart';

class MainPage3 extends StatefulWidget {
  const MainPage3({super.key});

  @override
  State<MainPage3> createState() => _MainPage3State();
}

class _MainPage3State extends State<MainPage3> {
  bool isOn = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              isOn ? "ON" : "OFF",
              style: TextStyle(fontSize: 20),
            ),
            SizedBox(height: 20),
            OnOffWidget3(
              initialState: isOn,
              onStateChange: (state) {
                setState(() {
                  isOn = state;
                });
              },
            )
          ],
        ),
      ),
    );
  }
}

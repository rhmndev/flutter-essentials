import 'package:flutter/material.dart';
import 'package:getting_info_from_custom_widget/on_off_widget2.dart';

class MainPage2 extends StatefulWidget {
  const MainPage2({super.key});

  @override
  State<MainPage2> createState() => _MainPage2State();
}

class _MainPage2State extends State<MainPage2> {
  OnOffWidgetController controller = OnOffWidgetController(isOn: true);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              controller.isOn ? "ON" : "OFF",
              style: TextStyle(fontSize: 20),
            ),
            SizedBox(height: 20),
            OnOffWidget2(
              controller,
              onStateChange: () {
                setState(() {});
              },
            )
          ],
        ),
      ),
    );
  }
}

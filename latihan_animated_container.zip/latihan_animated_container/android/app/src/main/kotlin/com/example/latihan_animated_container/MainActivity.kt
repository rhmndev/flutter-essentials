package com.example.latihan_animated_container

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

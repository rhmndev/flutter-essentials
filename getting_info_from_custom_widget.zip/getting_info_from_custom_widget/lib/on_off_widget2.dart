import 'package:flutter/material.dart';

class OnOffWidget2 extends StatefulWidget {
  // const OnOffWidget2({super.key});

  final OnOffWidgetController controller;
  final Function()? onStateChange;

  OnOffWidget2(this.controller, {this.onStateChange});

  @override
  State<OnOffWidget2> createState() => _OnOffWidget2State();
}

class _OnOffWidget2State extends State<OnOffWidget2> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        setState(() {
          widget.controller.isOn = !widget.controller.isOn;
        });

        if (widget.onStateChange != null) {
          widget.onStateChange!();
        }
      },
      child: Container(
          width: 100,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.black,
            borderRadius: BorderRadius.circular(25),
          ),
          child: AnimatedContainer(
            margin: EdgeInsets.only(
              top: 5,
              bottom: 5,
              left: widget.controller.isOn ? 55 : 5,
              right: widget.controller.isOn ? 5 : 55,
            ),
            width: 40,
            height: 40,
            duration: Duration(milliseconds: 500),
            decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: widget.controller.isOn ? Colors.yellow : Colors.grey),
          )),
    );
  }
}

class OnOffWidgetController {
  bool isOn;

  OnOffWidgetController({this.isOn = false});
}

import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: const Text("Latihan Image"),
        ),
        body: Center(
          child: Container(
            color: Colors.black,
            height: 200,
            width: 200,
            padding: const EdgeInsets.all(3),
            child: Image.network(
              "https://static.promediateknologi.id/crop/0x0:0x0/0x0/webp/photo/akuratco/images/akurat_20181204020943_Rh14CB.jpg",
              fit: BoxFit.cover,
            ),
          ),
        ),
      ),
    );
  }
}

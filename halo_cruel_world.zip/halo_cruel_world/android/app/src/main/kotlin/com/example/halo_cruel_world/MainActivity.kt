package com.example.halo_cruel_world

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

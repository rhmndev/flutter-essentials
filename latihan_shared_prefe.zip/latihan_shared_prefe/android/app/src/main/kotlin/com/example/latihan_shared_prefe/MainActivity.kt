package com.example.latihan_shared_prefe

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

import 'package:flutter/material.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.blue,
        body: Container(
          margin: const EdgeInsets.all(10),
          child: ListView(
            children: <Widget>[
              cardBuild(Icons.home_rounded, "Rumah Kami"),
              cardBuild(Icons.person, "Orang Hebat"),
              cardBuild(Icons.add_business, "Marketplace")
            ],
          ),
        ),
      ),
    );
  }

  Card cardBuild(IconData iconData, String text) {
    return Card(
      elevation: 5,
      child: Row(
        children: [
          Container(
            margin: const EdgeInsets.all(5),
            child: Icon(iconData, color: Colors.blue),
          ),
          Text(text)
        ],
      ),
    );
  }
}

# getting_info_from_custom_widget

A new Flutter project.

package com.example.texffield_widget

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

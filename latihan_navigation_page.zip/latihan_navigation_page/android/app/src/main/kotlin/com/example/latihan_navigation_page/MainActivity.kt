package com.example.latihan_navigation_page

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

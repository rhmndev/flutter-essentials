package com.example.caraousel_slider

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

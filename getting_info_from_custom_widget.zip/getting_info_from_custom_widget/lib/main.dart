import 'package:flutter/material.dart';
// import 'package:flutter/widgets.dart';
// import 'package:getting_info_from_custom_widget/main_Page2.dart';
import 'package:getting_info_from_custom_widget/main_page3.dart';
// import 'package:getting_info_from_custom_widget/on_off_widget.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MainPage3(),
    );
  }
}

// class MainPage extends StatefulWidget {
//   @override
//   _MainPageState createState() => _MainPageState();
// }

// class _MainPageState extends State<MainPage> {
//   bool isOn = false;

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Center(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             Text(
//               isOn ? "ON" : "OFF",
//               style: TextStyle(fontSize: 20),
//             ),
//             SizedBox(height: 20),
//             GestureDetector(
//               child: OnOffWidget1(isOn),
//               onTap: () {
//                 setState(() {
//                   isOn = !isOn;
//                 });
//               },
//             )
//           ],
//         ),
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class MainPage extends StatefulWidget {
  const MainPage({Key? key}) : super(key: key);

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  TextEditingController textEditingController = TextEditingController(text: '');
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        centerTitle: true,
        title: const Text('Input Decoration'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: textEditingController,
              onChanged: (value) => setState(() {}),
              decoration: const InputDecoration(
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(20)),
                ),
                icon: Icon(Icons.lock_outline),
                suffixIcon: Icon(Icons.person),
                // prefixText: "Name : ",
                suffixText: "What's your name?",
                labelText: "Masukan Nama",
                suffixStyle: TextStyle(
                  fontSize: 20,
                  color: Colors.blue,
                  fontWeight: FontWeight.bold,
                ),
              ),
              // obscureText: true,
              // obscuringCharacter: '!',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              // textAlign: TextAlign.center,
              cursorColor: Colors.red,
              inputFormatters: [
                TextInputFormatter.withFunction((oldValue, newValue) =>
                    TextEditingValue(text: newValue.text.toUpperCase()))
              ],
            ),
            const SizedBox(height: 20),
            Text(
              textEditingController.text,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            )
          ],
        ),
      ),
    );
  }
}
